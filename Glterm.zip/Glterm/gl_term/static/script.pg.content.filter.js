'use strict';

/* ---------------- Globals from original script ---------------- */
let a_or_b = '';
let current_data;
let ptsd_name = '';
let currentRoute = '';

/* ---------------- DOM References (updated for UmbrelOS layout) ---------------- */
const mainContent = document.querySelector('.app');
if (!mainContent) throw new Error('Main content container (#mainContent or .main-content) not found');
renderNavBar()
/* ---------------- Title / Sidebar Wiring ---------------- */
function renderNavBar() {
    document.querySelector('.sdc-app').innerHTML += `<div class="sidebar"></div>`
    let sidebar = document.querySelector('.sidebar')
    sidebar.innerHTML = `
        <div class="sidebar-item" onclick="ChangeContentMain('sys1$appx_list')">Home</div>
        <div class="sidebar-item" onclick="FetchData('/apisettings/chpass')">Ch Pass</div>
        <div class="sidebar-item" onclick="ChangeContentMain('sys1$Files')">Files</div>
         <div class="sidebar-item" onclick="ChangeContentMain('sys1$terminal')">Terminal</div>
         <div class="sidebar-item" onclick="ChangeContentMain('sys1$appstore')">AppStore</div>
        <div class="sidebar-item" onclick="location.href='/logout'">Logout</div>
    `;
}
wireUpNavItems()

function wireUpNavItems() {
    const links = Array.from(document.querySelectorAll('.sidebar-item[data-nav]'));
    links.forEach(item => {
        item.removeEventListener('click', onNavClick);
        item.addEventListener('click', onNavClick);
    });
}

function onNavClick(e) {
    const route = e.currentTarget.getAttribute('data-nav');
    if (!route) return;
    ChangeContentMain(route);
}

/* ---------------- Fetch Utilities ---------------- */
async function FetchData(url) {
    try {
        const res = await fetch(url, { credentials: 'same-origin' });
        if (!res.ok) {
            const msg = `Error ${res.status}: ${res.statusText}`;
            showToast(msg, 4000);
            return null;
        }
        const text = await res.text();
        mainContent.innerHTML = text
        return text;
    } catch (err) {
        const msg = `Fetch failed: ${err.message}`;
        showToast(msg, 4000);
        return null;
    }
}

/* ---------------- Main Content Module Loader ---------------- */
function ChangeContentMain(moduleName, path = '/index') {
    SetHrefLink(moduleName);
    FetchData(`/modules/${moduleName}${path}`)
}

/* ---------------- Settings UI Logic ---------------- */
function LoadSettingsOption(settings) {
    if (!mainContent) return;
    let routeToSet = '';
    let html = '';

    if (settings === 'main_list') {
        routeToSet = 'main_list';
        FetchData('/apisettings/lists');
    } else if (settings === 'About') {
        routeToSet = 'Settings/About';
        html = `<h2>About</h2><p>This is your GL_TERM App.</p>`;
        SetHrefLink(routeToSet);
        mainContent.innerHTML = html;
    } else {
        return LoadSettingsOption('main_list');
    }

    updateTitlebarButtons();
}

function wireUpSettingsLinks() {
    const links = Array.from(mainContent.querySelectorAll('.settings-link'));
    links.forEach(link => {
        link.removeEventListener('click', onSettingsLinkClick);
        link.addEventListener('click', onSettingsLinkClick);
    });
}

function onSettingsLinkClick(e) {
    e.preventDefault();
    const setting = e.currentTarget.dataset.setting;
    if (!setting) return;
    LoadSettingsOption(setting);
}

/* ---------------- History Management ---------------- */
function SetHrefLink(hreflink) {
    try {
        currentRoute = hreflink || '';
        const newHash = `#/${hreflink}`;
        history.pushState(null, '', newHash);
    } catch (err) {
        currentRoute = hreflink;
        console.warn('SetHrefLink warning:', err);
    }
}

window.addEventListener('popstate', () => {
    const hash = (location.hash || '').replace(/^#\//, '');
    currentRoute = hash;
});

/* ---------------- Toasts (unchanged) ---------------- */
function showToast(message, timeout = 2000) {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.setAttribute('aria-live', 'polite');
        document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    container.appendChild(toast);
    void toast.offsetHeight; // force reflow
    toast.classList.add('show');
    if (timeout > 0) {
        setTimeout(() => removeToast(toast), timeout);
    }
    return toast;
}

function removeToast(toast) {
    if (!toast || !toast.parentElement) return;
    toast.classList.add('hide');
    toast.addEventListener('transitionend', () => {
        if (toast.parentElement) toast.remove();
    }, { once: true });
}

/* ---------------- Sidebar Open/Close ---------------- */

/* ---------------- Outside Click for Sidebar ---------------- */
/* ---------------- Initial Setup ---------------- */
renderNavBar();
// Start default route (e.g., show settings main list or your home logic):
ChangeContentMain('sys1$appx_list');

document.querySelectorAll('.sidebar')[1].remove()
document.addEventListener("DOMContentLoaded", () => {
    const contextMenu = document.getElementById("appContextMenu");
    let currentCard = null;

    document.querySelectorAll(".app-card").forEach(card => {
        card.addEventListener("contextmenu", e => {
            e.preventDefault();
            currentCard = card;

            const menuWidth = 160; 
            const menuHeight = contextMenu.offsetHeight || 100;
            let x = e.pageX;
            let y = e.pageY;

            if (x + menuWidth > window.innerWidth) x = window.innerWidth - menuWidth - 10;
            if (y + menuHeight > window.innerHeight) y = window.innerHeight - menuHeight - 10;

            contextMenu.style.top = y + "px";
            contextMenu.style.left = x + "px";
            contextMenu.style.display = "block";
        });
    });

    document.addEventListener("click", () => {
        contextMenu.style.display = "none";
    });

    contextMenu.querySelectorAll(".context-item").forEach(item => {
        item.addEventListener("click", () => {
            if (!currentCard) return;

            const action = item.dataset.action;
            const title = currentCard.dataset.title;
            const startCmd = currentCard.dataset.start;
            const stopCmd = currentCard.dataset.stop;
            const port = currentCard.dataset.port;

            if (action === "start") fetch(`/termapi?cmd=${startCmd}`);
            else if (action === "stop") fetch(`/termapi?cmd=${stopCmd}`);
            else if (action === "open") window.open(`http://192.168.1.5:${port}`);

            contextMenu.style.display = "none";
        });
    });
});
document.addEventListener("contextmenu", function(e){
    const card = e.target.closest(".app-card");
    if (!card) return;
    e.preventDefault();
    currentCard = card;

    const contextMenu = document.getElementById("appContextMenu");
    contextMenu.style.top = e.pageY + "px";
    contextMenu.style.left = e.pageX + "px";
    contextMenu.style.display = "block";
});